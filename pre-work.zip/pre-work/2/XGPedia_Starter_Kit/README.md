# XGPedia — کیت شروع خط تولید

مخزن اسکلت مطابق سند نهایی «FOOTBALL MEDIA ENGINE — XGPedia» (نسخهٔ ادغام‌شدهٔ ۶.۰).

## قانون طلایی

عدد را API می‌دهد، متن را مدل زبانی می‌نویسد، تصویر را قالب HTML می‌سازد و
انتشار را زمان‌بند انجام می‌دهد — مدل زبانی هرگز عددی از حافظهٔ خودش نمی‌نویسد.
هر عددِ منتشرشده باید تا پاسخ خام provider ردیابی‌پذیر باشد.

## شروع سریع

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
python -m playwright install chromium
cp .env.example .env            # کلیدها را پر کن؛ هرگز .env را کامیت نکن
python run.py init              # ساخت SQLite
python -m pytest tests/ -v     # قواعد حیاتی سبز شوند
python run.py test-provider --matches 5   # آزمون پوشش؛ خروجی docs/provider-test.md
```

## ساختار

```
config/          brand/thresholds/glossary — تصمیم‌ها در JSON، نه در کد
brand/           brand.json + لوگوها + فونت Vazirmatn
src/xgpedia/
  providers/     آداپتر هر provider — خروجی schema داخلی واحد (درس FBref)
  normalization/ Pydantic schema؛ null≠0
  analytics/     محاسبهٔ قطعی — LLM اینجا نیست
  editorial/    LLMProvider قابل تعویض + validator هفت‌دروازه‌ای
  render/        HTML→PNG/JPEG با Playwright (Jinja2 + brand.json)
  publishers/    ربات تأیید/انتشار تلگرام
tests/           قواعد حیاتی + مجموعهٔ تزریق ۳۰ خطا (Gate 3)
docs/            decisions.md, provider-test.md, corrections.md, calendar.md
```

## دروازه‌ها (Go/No-Go)

- **Gate 1 (پایان هفتهٔ ۲):** ≥۲۵ پست منتشرشده + baseline هر دسته + صفر خطای عددی بحرانی
- **Gate 2 (پایان هفتهٔ ۳):** تصمیم منبع داده و xG بر پایهٔ آزمون واقعی؛ JSON فردا بدون خطا
- **Gate 3 (پایان هفتهٔ ۴):** validator ۱۰۰٪ روی ۳۰ خطای تزریقی + ≥۹۰٪ خروجی قابل‌تأیید در ۲۰ مسابقه
- **Gate 4 (هفتهٔ ۹):** ۱۴ روز بدون خطای مهم برای هر دسته → فقط همان دسته بدون تأیید انسانی

## خط قرمز مطلق

هیچ توصیه، CTA، تبلیغ یا لحن «خط بازار» دربارهٔ شرط‌بندی — نه توسط انسان، نه مدل.
